package com.paulo.javabase.practice;

public interface AnonymousInterface {
    void show();
}
