package com.paulo.javabase.practice.file;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterTest {
    public static void main(String[] args) throws IOException {
        FileWriter fw = new FileWriter("d:\\1.txt");

    }
}
