package com.paulo.javabase.module2;

public interface NetService {
    void call(double netFlow, PhoneCard phoneCard);
}
