package com.paulo.javabase.module4.task1;

public class StuNoException extends Exception {
    public StuNoException(String message){
        super(message);
    }
}
