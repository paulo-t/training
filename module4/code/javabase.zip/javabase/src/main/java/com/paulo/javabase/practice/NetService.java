package com.paulo.javabase.practice;

import com.paulo.javabase.module2.PhoneCard;

public interface NetService {
    void call(double netFlow, PhoneCard phoneCard);
}
