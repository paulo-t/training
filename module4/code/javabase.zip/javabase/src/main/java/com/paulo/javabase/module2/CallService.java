package com.paulo.javabase.module2;

/**
 * 通话服务
 */
public interface CallService {

   void call(int count, PhoneCard phoneCard);
}
