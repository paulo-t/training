package com.paulo.javabase.practice;

import java.util.ArrayList;
import java.util.Collection;

public class CollectionTest {
    public static void main(String[] args) {
        Collection collection = new ArrayList();
        collection.isEmpty();
        collection.add("1");
    }
}
