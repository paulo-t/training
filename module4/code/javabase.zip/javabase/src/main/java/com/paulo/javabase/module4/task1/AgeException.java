package com.paulo.javabase.module4.task1;

public class AgeException extends Exception {
    public AgeException(String message){
        super(message);
    }
}
